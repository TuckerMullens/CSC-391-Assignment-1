import cv2
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import axes3d
import skimage as ski

path = 'C:/Users/manly/Documents/CSC 391 Assignment1/dogreg.jpg'
img = cv2.imread(path, 0)

userInput = input('Enter 1 for frequency analysis of one image, enter 2 for superimposition of frequency magnitudes of multiple images or 3 for Inverse Fourier reconstruction: ')

#Creating Figure for Graphing
xx, yy = np.mgrid[0:img.shape[0], 0:img.shape[1]]
fig = plt.figure()
ax = fig.gca(projection='3d')

if userInput == '1':
    #Calculating Fourier Transform and Axes for plots
    FreqData = np.fft.fft2(img.astype(float))

    Y = (np.linspace(-int(img.shape[0]/2), int(img.shape[0]/2)-1, img.shape[0]))
    X = (np.linspace(-int(img.shape[1]/2), int(img.shape[1]/2)-1, img.shape[1]))
    X, Y = np.meshgrid(X, Y)

    #Plotting Frequency Mags
    ax.plot_surface(X, Y, np.fft.fftshift(np.abs(FreqData)), cmap=plt.cm.coolwarm, linewidth=0, antialiased=False)
    plt.show()
    #fig.savefig('C:/Users/manly/Documents/CSC 391 Assignment1/FrequencyAnalysis/excess.jpg')

    #Plotting log Frequency Mags + 1
    fig = plt.figure()
    ax = fig.gca(projection='3d')
    ax.plot_surface(X, Y, np.fft.fftshift(np.log(np.abs(FreqData)+1)), cmap=plt.cm.coolwarm, linewidth=0, antialiased=False)
    plt.show()
    #fig.savefig('C:/Users/manly/Documents/CSC 391 Assignment1/FrequencyAnalysis/excess.jpg')

    # Plot the magnitude and the log(magnitude + 1) as images (view from the top)
    magnitudeImage = np.fft.fftshift(np.abs(FreqData))
    magnitudeImage = magnitudeImage / magnitudeImage.max()
    magnitudeImage = ski.img_as_ubyte(magnitudeImage)
    cv2.imshow('Magnitude plot', magnitudeImage)
    cv2.waitKey(0)
    #cv2.imwrite('C:/Users/manly/Documents/CSC 391 Assignment1/FrequencyAnalysis/excess.jpg', magnitudeImage)

    logMagnitudeImage = np.fft.fftshift(np.log(np.abs(FreqData)+1))
    logMagnitudeImage = logMagnitudeImage / logMagnitudeImage.max()   # scale to [0, 1]
    logMagnitudeImage = ski.img_as_ubyte(logMagnitudeImage)
    cv2.imshow('Log Magnitude plot', logMagnitudeImage)
    cv2.waitKey(0)
    #cv2.imwrite('C:/Users/manly/Documents/CSC 391 Assignment1/FrequencyAnalysis/excess.jpg', logMagnitudeImage)
elif userInput == '2':
    #Loading in other images
    path = 'C:/Users/manly/Documents/CSC 391 Assignment1/landscape1.jpg'
    img2 = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    path = 'C:/Users/manly/Documents/CSC 391 Assignment1/landscape2.jpg'
    img3 = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    path = 'C:/Users/manly/Documents/CSC 391 Assignment1/landscape3.jpg'
    img4 = cv2.imread(path, cv2.IMREAD_GRAYSCALE)


    #Plotting and Superimposing log Freq Mags + 1 for 4 images
    FreqData = np.fft.fft2(img.astype(float))
    Y = (np.linspace(-int(img.shape[0] / 2), int(img.shape[0] / 2) - 1, img.shape[0]))
    X = (np.linspace(-int(img.shape[1] / 2), int(img.shape[1] / 2) - 1, img.shape[1]))
    X, Y = np.meshgrid(X, Y)
    ax.plot_surface(X, Y, np.fft.fftshift(np.log(np.abs(FreqData)+1)), color ='r', linewidth=0, antialiased=False)
    
    FreqData = np.fft.fft2(img2.astype(float))
    Y = (np.linspace(-int(img2.shape[0] / 2), int(img2.shape[0] / 2) - 1, img2.shape[0]))
    X = (np.linspace(-int(img2.shape[1] / 2), int(img2.shape[1] / 2) - 1, img2.shape[1]))
    X, Y = np.meshgrid(X, Y)
    ax.plot_surface(X, Y, np.fft.fftshift(np.log(np.abs(FreqData)+1)), color='g', linewidth=0, antialiased=False)
    
    
    FreqData = np.fft.fft2(img3.astype(float))
    Y = (np.linspace(-int(img3.shape[0] / 2), int(img3.shape[0] / 2) - 1, img3.shape[0]))
    X = (np.linspace(-int(img3.shape[1] / 2), int(img3.shape[1] / 2) - 1, img3.shape[1]))
    X, Y = np.meshgrid(X, Y)
    ax.plot_surface(X, Y, np.fft.fftshift(np.log(np.abs(FreqData)+1)), color='b', linewidth=0, antialiased=False)

    FreqData = np.fft.fft2(img4.astype(float))
    Y = (np.linspace(-int(img4.shape[0] / 2), int(img4.shape[0] / 2) - 1, img4.shape[0]))
    X = (np.linspace(-int(img4.shape[1] / 2), int(img4.shape[1] / 2) - 1, img4.shape[1]))
    X, Y = np.meshgrid(X, Y)
    ax.plot_surface(X, Y, np.fft.fftshift(np.log(np.abs(FreqData)+1)), color='y', linewidth=0, antialiased=False)

    plt.show()
elif userInput == '3':
    #Inverse Fourier image reconstruction cutting off low frequencies first, then high frequencies
    FreqData = np.fft.fft2(img)
    FreqDataShift = np.fft.fftshift(FreqData)
    FreqData_orig = FreqDataShift.copy()
    rows, cols = img.shape
    half_row, half_col = int(rows / 2), int(cols / 2)
    FreqDataShift[half_row - 30:half_row + 30, half_col - 30:half_col + 30] = 0
    FreqDataIShift = np.fft.ifftshift(FreqDataShift)
    img_back = np.fft.ifft2(FreqDataIShift)
    img_back = np.abs(img_back)
    # cv2.imshow('returned', img_back)
    plt.subplot(133), plt.imshow(img_back)
    plt.show()
    f_ishift = np.fft.ifftshift(FreqData_orig - FreqDataShift)
    img_back = np.fft.ifft2(f_ishift)
    img_back = np.abs(img_back)
    plt.subplot(133), plt.imshow(img_back)
    plt.show()