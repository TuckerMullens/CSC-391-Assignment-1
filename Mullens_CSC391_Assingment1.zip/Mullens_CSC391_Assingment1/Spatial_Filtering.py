import cv2
import numpy as np

path = 'C:/Users/manly/Documents/CSC 391 Assignment1/landscape2.jpg'
img = cv2.imread(path)

filterop = input('Enter B for box filter, G for gaussian filter, or C for canny edge detection: ')
if filterop == 'B':

    #Box Filtering the Image
    windowLen = int(input("Enter the size of the filter: "))
    w = np.ones((windowLen, windowLen), np.float32)
    w = w / w.sum()
    filtered = np.zeros(img.shape, np.float64)
    filtered[:, :, 0] = cv2.filter2D(img[:, :, 0], -1, w)
    filtered[:, :, 1] = cv2.filter2D(img[:, :, 1], -1, w)
    filtered[:, :, 2] = cv2.filter2D(img[:, :, 2], -1, w)
    filtered = filtered / img.max()  # scale to [min/max, 1]
    filtered = filtered * 255 # scale to [min/max*255, 255]

    #Displaying and saving the original image
    cv2.imshow('original', img)
    cv2.waitKey(0)
    #cv2.imwrite('original.jpg', img)
    #Displaying and saving the filter
    cv2.imshow('filter', w.astype(np.uint8))
    cv2.waitKey(0)
    #cv2.imwrite('filter.jpg', w.astype(np.uint8))
    #Displaying and saving the filtered image
    cv2.imshow('denoised', filtered.astype(np.uint8))  # convert to uint8
    cv2.waitKey(0)
    cv2.imwrite('filteredimage.jpg', filtered.astype(np.uint8))
    #cv2.imwrite('C:/Users/manly/Documents/CSC 391 Assignment1/SpatialFiltering/bfilteredimage.jpg', filtered.astype(np.uint8))
elif filterop == 'G':
    #Applying Gaussian Filter to the image
    windowLen = int(input('Enter the size of the filter: '))
    filtered = cv2.GaussianBlur(img, (windowLen, windowLen), 0)
    cv2.imshow('original', img)
    cv2.waitKey(0)
    cv2.imshow('filtered', filtered)
    cv2.waitKey(0)
    #cv2.imwrite('C:/Users/manly/Documents/CSC 391 Assignment1/SpatialFiltering/gfilteredimage.jpg',filtered.astype(np.uint8))
elif filterop == 'C':
    #Applying Canny Edge Detection to the image
    minSize = int(input('Enter min size: '))
    maxSize = int(input('Enter max size: '))
    edges = cv2.Canny(img, minSize, maxSize)
    cv2.imshow('original', img)
    cv2.waitKey(0)
    cv2.imshow('edges', edges)
    cv2.waitKey(0)
    #cv2.imwrite('C:/Users/manly/Documents/CSC 391 Assignment1/SpatialFiltering/edgesnoise.jpg',edges.astype(np.uint8))