import cv2
import numpy as np
import matplotlib.pyplot as plt
import skimage as ski
from mpl_toolkits.mplot3d import Axes3D

#Importing images and user input for filter order
path = 'C:/Users/manly/Documents/CSC 391 Assignment1/dogreg.jpg'
img = cv2.imread(path, 0)

n = int(input('Enter the desired order of the Butterworth Filter: '))

#Creaing Axes for Later Use
Y = (np.linspace(-int(img.shape[0]/2), int(img.shape[0]/2)-1, img.shape[0]))
X = (np.linspace(-int(img.shape[1]/2), int(img.shape[1]/2)-1, img.shape[1]))
X, Y = np.meshgrid(X, Y)

#Plotting Frequency Data of Original Image
FreqData_orig = np.fft.fft2(img)
fig = plt.figure()
ax = fig.gca(projection='3d')
ax.plot_surface(X, Y, np.fft.fftshift(np.log(np.abs(FreqData_orig)+1)), cmap=plt.cm.coolwarm, linewidth=0, antialiased=False)
plt.show()

#Creating and Applying Lowpass Butterworth filter to image
U = (np.linspace(-int(img.shape[0]/2), int(img.shape[0]/2)-1, img.shape[0]))
V = (np.linspace(-int(img.shape[1]/2), int(img.shape[1]/2)-1, img.shape[1]))
U, V = np.meshgrid(U, V)
D = np.sqrt(X*X + Y*Y)
xval = np.linspace(-int(img.shape[1]/2), int(img.shape[1]/2)-1, img.shape[1])
D0 = 0.15 * D.max()
colors='brgkmc'
FTgraySmall = np.fft.fft2(img.astype(float))
H = 1.0 / (1 + (np.sqrt(2) - 1)*np.power(D/D0, 2*n))
FTgraySmallFiltered = FTgraySmall * np.fft.fftshift(H)

#Plotting Frequency Data of Butterworth applied Image
fig = plt.figure()
ax = fig.gca(projection='3d')
ax.plot_surface(X, Y, np.fft.fftshift(np.log(np.abs(FTgraySmallFiltered)+1)), cmap=plt.cm.coolwarm, linewidth=0, antialiased=False)
plt.show()

#Plotting Frequency Data of Original Image as Image
logMagnitudeImage = np.fft.fftshift(np.log(np.abs(FreqData_orig)+1))
logMagnitudeImage = logMagnitudeImage / logMagnitudeImage.max()   # scale to [0, 1]
logMagnitudeImage = ski.img_as_ubyte(logMagnitudeImage)
cv2.imshow('Log Magnitude plot', logMagnitudeImage)
cv2.waitKey(0)
#cv2.imwrite('C:/Users/manly/Documents/CSC 391 Assignment1/Frequency_Filtering/Original_log_freq_plot.jpg', logMagnitudeImage)

#Plotting Frequency Data of Butterworth applied Image as Image
logMagnitudeImage = np.fft.fftshift(np.log(np.abs(FTgraySmallFiltered)+1))
logMagnitudeImage = logMagnitudeImage / logMagnitudeImage.max()   # scale to [0, 1]
logMagnitudeImage = ski.img_as_ubyte(logMagnitudeImage)
cv2.imshow('Log Magnitude plot', logMagnitudeImage)
cv2.waitKey(0)
#cv2.imwrite('C:/Users/manly/Documents/CSC 391 Assignment1/Frequency_Filtering/Butterworth_log_freq_plot.jpg', logMagnitudeImage)

#Displaying Low Pass Butterworth Image
graySmallFiltered = np.abs(np.fft.ifft2(FTgraySmallFiltered))
graySmallFiltered = ski.img_as_ubyte(graySmallFiltered / graySmallFiltered.max())
cv2.imshow('Butterworth_LowPass', graySmallFiltered)
cv2.waitKey(0)
cv2.imwrite('C:/Users/manly/Documents/CSC 391 Assignment1/Frequency_Filtering/butterworth low pass dog2.jpg', graySmallFiltered)

#Apply High Pass Butterworth to Image and then Display Results
highpass_butter = 1 - H
FTgraySmallFiltered = FTgraySmall * np.fft.fftshift(highpass_butter)
graySmallFiltered = np.abs(np.fft.ifft2(FTgraySmallFiltered))
graySmallFiltered = ski.img_as_ubyte(graySmallFiltered / graySmallFiltered.max())
cv2.imshow('Butterworth High Pass', graySmallFiltered)
cv2.waitKey(0)
cv2.imwrite('C:/Users/manly/Documents/CSC 391 Assignment1/Frequency_Filtering/butterworth high pass dog2.jpg', graySmallFiltered)

#Displaying Ideal Low Passed Image
idealLowPass = D <= D0
FTgraySmall = np.fft.fft2(img.astype(float))
FTgraySmallFiltered = FTgraySmall * np.fft.fftshift(idealLowPass)
graySmallFiltered = np.abs(np.fft.ifft2(FTgraySmallFiltered))
graySmallFiltered = ski.img_as_ubyte(graySmallFiltered / graySmallFiltered.max())
cv2.imshow('Ideal Low Pass', graySmallFiltered)
cv2.waitKey(0)
cv2.imwrite('C:/Users/manly/Documents/CSC 391 Assignment1/Frequency_Filtering/ideal low pass dog2.jpg', graySmallFiltered)

#Displaying Ideal High Passed Image
idealHighPass = D >= D0
FTgraySmall = np.fft.fft2(img.astype(float))
FTgraySmallFiltered = FTgraySmall * np.fft.fftshift(idealHighPass)
graySmallFiltered = np.abs(np.fft.ifft2(FTgraySmallFiltered))
graySmallFiltered = ski.img_as_ubyte(graySmallFiltered / graySmallFiltered.max())
cv2.imshow('Ideal High Pass', graySmallFiltered)
cv2.waitKey(0)
cv2.imwrite('C:/Users/manly/Documents/CSC 391 Assignment1/Frequency_Filtering/ideal high pass dog2.jpg', graySmallFiltered)